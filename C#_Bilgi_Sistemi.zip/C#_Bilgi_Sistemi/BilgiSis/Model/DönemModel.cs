﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
 public   class DönemModel
    {
        public int DönemID { get; set; }
        public string DonemAdi { get; set; }

    }
}
