﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class AkademikBirimModel
    {
        public int AkademikBirimID { get; set; }
        public string AkademikBirimAdi { get; set; }
    }
}
