﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class OgrenciModel
    {
        public int OgrenciID { get; set; }
        public int OgrenciNo { get; set; }
        public string OgrenciAdi { get; set; }
        public string OgrenciSoyadi { get; set; }
        public string OgrenciSifre { get; set; }
        public int BolumlerID { get; set; }
    }
}
