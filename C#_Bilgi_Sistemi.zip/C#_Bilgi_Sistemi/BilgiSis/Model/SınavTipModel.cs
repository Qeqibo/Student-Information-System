﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
public    class SınavTipModel
    {
        public int SınavTipID { get; set; }
        public string SınavTipAdi { get; set; }
        public int Agırlık { get; set; }
    }
}
