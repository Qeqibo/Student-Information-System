﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
public  class AdminModel
    {
        public int AdminID { get; set; }

        public string AdminAd { get; set; }

        public string AdminSoyad { get; set; }

        public string AdminSifre { get; set; }
    }
}
