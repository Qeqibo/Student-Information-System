﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
   public class DevamsızlıkModel
    {
        public int OgrenciID { get; set; }
        public int DersID { get; set; }
        public DateTime Tarih { get; set; }
    }
}
