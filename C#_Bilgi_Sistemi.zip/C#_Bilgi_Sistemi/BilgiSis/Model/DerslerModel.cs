﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MODEL
{
    public class DerslerModel
    {
        public int DersID { get; set; }
        public string DersKodu { get; set; }
        public int BolumlerID { get; set; }
        public int DonemID { get; set; }


    }
}
