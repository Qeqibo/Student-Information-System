﻿namespace MODEL
{
    public class OgretimElemaniModel
    {
        public string OgrElemaniTC { get; set; }
        public string OgrElemaniAdi { get; set; }
        public string OgrElemaniSoyad { get; set; }
        public int BolumlerID { get; set; }
        public string OgrElemaniSifre { get; set; }
        public string OgrElemaniSicilNo { get; set; }
    }
}
